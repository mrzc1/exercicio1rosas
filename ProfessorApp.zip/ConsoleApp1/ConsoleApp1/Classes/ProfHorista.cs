﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.NovaPasta
{
    internal class ProfHorista : Professor
    {
        private double valorHora { get; set; }
        public override void calcularBeneficio() => Console.WriteLine("ProfHorista: Calculando beneificio");
    }
}
