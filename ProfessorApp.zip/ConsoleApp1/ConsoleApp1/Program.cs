﻿using ConsoleApp1.NovaPasta;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
         Console.WriteLine("==================Professor DE==================");
         ProfDE pd = new ProfDE();
         pd.calcularBeneficio();
         
         Console.WriteLine("==================Professor Horista==================");
         ProfHorista ph = new ProfHorista();
         ph.calcularBeneficio();
        }
    }
}
